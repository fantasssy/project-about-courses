package com.ch5.CH5;

import java.sql.*;

/**
 * @author 25560
 */
public class SQLBean {
    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;

    public SQLBean() throws ClassNotFoundException, SQLException {
        String driverName = "com.mysql.cj.jdbc.Driver";
        String username = "root";
        String password = "123456";
        String dbname = "staff";
        String url = "jdbc:mysql://localhost:3306/" + dbname + "?characterEncoding=utf-8&useSSL=false&serverTimezone=UTC";
        Class.forName(driverName);
        connection = DriverManager.getConnection(url, username, password);
    }

    public void execute(String sql) throws SQLException {
        statement = connection.createStatement();
        statement.execute(sql);
    }

    /**
     * 更新操作
     */
    public void executeUpdate(String sql) throws SQLException {
        statement = connection.createStatement();
        statement.executeUpdate(sql);

    }

    /**
     * 查询操作
     */

    public ResultSet executeQuery(String sql) throws SQLException {
        statement = connection.createStatement();
        resultSet = statement.executeQuery(sql);
        return resultSet;
    }

    public void close() throws SQLException {
        statement.close();
        connection.close();
    }
}
